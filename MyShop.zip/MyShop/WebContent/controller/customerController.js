function login(){
		var username = document.getElementById("txtUsername").value;
		var password = document.getElementById("txtPassword").value;
		var request = getRequest();
		request.onload = function() {
			if(request.responseText == "login success"){
				alert("you logged in");
				doSubmit();
			}
		};
		request.open("GET", "Login?username=" + username + "&password=" + password, true);
		request.send(null);
	}
	
	function doSubmit()
	{
		window.location.replace("http://localhost:8080/VShop/item.jsp"); 
	}
	
	function getRequest() {
		var xmlHttp;
		try {
			// Firefox, Opera 8.0+, Safari
			xmlHttp = new XMLHttpRequest();
		} catch (e) {
			// Internet Explorer
			try {
				xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {
					alert("Your browser does not support AJAX!");
					return false;
				}
			}
		}
		return xmlHttp;
	}