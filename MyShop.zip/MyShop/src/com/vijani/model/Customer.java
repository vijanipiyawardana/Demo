package com.vijani.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.vijani.database.DBConnector;
import com.vijani.database.DBHandler;

public class Customer {
	private String username;
	private String password;
	
	public Customer(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}

	public boolean login() throws ClassNotFoundException, SQLException{
		String s = isValidFormLogin(username, password);
		if(s=="success") {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean logout() {
		return true;
	}
	
	private String isValidFormLogin(String username, String password) throws ClassNotFoundException, SQLException{
		String status = "invalid user credentials...!";
		String query = "SELECT * FROM customer;";
		ResultSet rst = DBHandler.getData(DBConnector.getConnectionToDB(), query);
		
		String usernameDB = "";
		String passwordDB = "";
		while(rst.next()) {
			usernameDB = rst.getString(1);
			passwordDB = rst.getString(2);
			
			if((usernameDB.equals(username)) && passwordDB.equals(password)) {
				status = "success";
				break;
			}	
		}
		return status;
	}
	
	public boolean isLoggedCustomer() {
		return true;
	}
	
}