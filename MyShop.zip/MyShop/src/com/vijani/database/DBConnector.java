package com.vijani.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector {

	public static final String URL = "jdbc:mysql://localhost/vshop";
	public static final String USERNAME = "root";
	public static final String PASSWORD = "";
	
	private static  DBConnector dbConnector=null;
    private  Connection con=null;
    
    private DBConnector() throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection(URL,USERNAME,PASSWORD);
    }
    private  static DBConnector getDBConnector() throws ClassNotFoundException, SQLException{
        if(dbConnector==null){
            dbConnector=new DBConnector();
        }
        return dbConnector;
    }

    public static Connection getConnectionToDB() throws ClassNotFoundException, SQLException{

        return getDBConnector().con;

    }
    
}
