package com.vijani.dcbus;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vijani.model.Customer;

public class CustomerLoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1024933026485904788L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Boolean b = false;
		Customer customer = new Customer(username,password);
		
		try {
			b = customer.login();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(b) {
			response.getWriter().write("login success");
		}
		else {
			response.getWriter().write("login failed");
		}
		System.out.println("Login OK");
	}
}
