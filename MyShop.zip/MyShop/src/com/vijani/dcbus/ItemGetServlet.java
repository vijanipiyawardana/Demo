package com.vijani.dcbus;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.vijani.model.Item;


public class ItemGetServlet extends HttpServlet {

	private static final long serialVersionUID = 8539109743178761761L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		ArrayList<Item> items = null;
		Item item = new Item();
		
		try {
			items = item.getAllItems();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ObjectMapper mapper = new ObjectMapper(); 
        String itemsString = mapper.writeValueAsString(items);
		response.getWriter().append(itemsString);	
	}
}
