package com.vijani.dcbus;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vijani.model.Item;

public class DeleteItemServlet extends HttpServlet{

	private static final long serialVersionUID = 1352227850751115905L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	
		Integer id = (Integer.parseInt(request.getParameter("id")));
		
		Item item = new Item();
		
		try {
			System.out.println("Item deleted...! "+ item.deleteItem(id));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		 response.getWriter().write("item deleted");
	}
	
}
