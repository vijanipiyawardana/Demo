package com.vijani.dcbus;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LogoutServlet extends HttpServlet{

	private static final long serialVersionUID = -76213742620074868L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//request.getRequestDispatcher("index.jsp").forward(request, response);
		RequestDispatcher dispatcher = this.getServletContext().getRequestDispatcher("/index.jsp");
        
	    dispatcher.forward(request, response);
		
	}
}
