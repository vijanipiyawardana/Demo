<?php
$con=mysqli_connect("localhost","root","","test") or die("DB Connection Error");
?>