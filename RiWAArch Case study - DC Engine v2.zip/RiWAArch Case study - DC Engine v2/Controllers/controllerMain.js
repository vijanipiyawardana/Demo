var DCBusIndex = "Model/index.php";

//==CONTROLLER=======================================================================================
//--User----------------------------------------------------------


//--Login--------------------
$(document).on("click","#btnLogin",function() 
{
   $("#divStsMsgLogin").html("");
   var result = isValidFormLogin();//use client-Model
   
   if(result=="true")
   {
       $.ajax
       ({
           type: "post", 
           url: DCBusIndex + "/user/null", 
           data: $("#formLogin").serialize(), 
           complete: function(response, status){ onLogingComplete(response.responseText, status);}
        });
   }
   else {  $("#divStsMsgLogin").html(result);  }
});

function onLogingComplete(response, status)
{
    //status = "success", "notmodified", "nocontent", "error", "timeout", "abort", or "parsererror"
    if(status=="success")
    {
        if(response=="true") {  document.location = "items.php"; }
        else {  $("#divStsMsgLogin").html(response); }
    }
    else if(status=="error") { $("#divStsMsgLogin").html("Error while authenticating"); }
    else { $("#divStsMsgLogin").html("Unknown error while authenticating"); }    
}




//--Logout--------------
$(document).on("click","#btnLogout", function()
{ 
    $.ajax
    ({
        type: "delete", 
        url: DCBusIndex + "/user/null", 
        complete: function(response, status){ onLogOutComplete(response.responseText, status); }
     }); 
});

function onLogOutComplete(response, status)
{
    if(status=="success") {  document.location = "index.php"; }
    else if(status=="error") { alert("Error while loging out"); }
    else { alert("Unknown error while loging out"); }
}




//--Items-----------------------------------------------------
//--Refresh-----------
$(document).on("click","#btnRefresh", function()
{
   $("#divStsMsgItem").html("Loading...");   

   $.ajax
   ({
      type: "get",
      url: DCBusIndex + "/item/null",
      complete: function(response, status){ onRefreshComplete(response.responseText, status); }
   })
});

function onRefreshComplete(response, status)
{
    if(status=="success") 
    {  
       $("#divItemsTable").html(response);
       $("#divStsMsgItem").html("Loaded successfully");
    }
    else if(status=="error") { $("#divStsMsgItem").html("Error while loading");   }
    else { $("#divStsMsgItem").html("Unknown error while loading");   }
}


//--Save--------------
$(document).on("click","#btnSave", function()
{
   var result = isValidFormItem();//use client-Model
   
   if(result == "true")
   { 
        $("#divStsMsgItem").html("Saving...");

        $.ajax
        ({
            type: "post",
            url: DCBusIndex + "/item/"+($("#hidItemID").val()=="0"?"null":$("#hidItemID").val()),
            data:$("#formItems").serialize(),
            complete: function(response, status){ onSaveUpdateComplete(response.responseText, status); }
        });
   }
   else
   {  $("#divStsMsgItem").html(result);   }
});

function onSaveUpdateComplete(response, status)
{
    if(status=="success") 
    {  
        $("#formItems")[0].reset();
        $("#divItemsTable").html(response);     
        $("#divStsMsgItem").html("Saved successfully"); 
    }
    else if(status=="error") { $("#divStsMsgItem").html("Error while saving");   }
    else { $("#divStsMsgItem").html("Unknown error while saving");   } 
}



//--Edit---------------
$(document).on("click", "#btnEdit", function()
{
   $("#hidItemID").val($(this).data("itemid"));
   $("#txtItemName").val($(this).closest("tr").find('td:eq(1)').text());
   $("#txtItemDesc").val($(this).closest("tr").find('td:eq(2)').text());
});



//--Delete------------
$(document).on("click", "#btnRemove", function()
{
    $("#divStsMsgItem").html("Removing...");  

    $.ajax
    ({
       type: "delete",
       url: DCBusIndex + "/item/" + $(this).data("itemid"),
       complete: function(response, status){ onItemDeleteComplete(response.responseText, status); }
    });
});

function onItemDeleteComplete(response, status)
{
    if(status=="success") 
    {  
        $("#divItemsTable").html(response);
        $("#divStsMsgItem").html("Removed successfully");
    }
    else if(status=="error") { $("#divStsMsgItem").html("Error while removing");   }
    else { $("#divStsMsgItem").html("Unknown error while removing");   } 
}




//==CLIENT-MODEL====================================================================================
//--User------------------------
function isValidFormLogin()
{
   if($.trim($("#txtUserName").val())=="")
   {  return "Enter Username";   }
   
   if($.trim($("#txtPassword").val())=="")
   {  return "Enter Password";   }
   
   return "true";
}

//--Item-----------------------
function isValidFormItem()
{
   if($.trim($("#txtItemName").val())=="")
   {  return "Enter item name";  }
   
   if($.trim($("#txtItemDesc").val())=="")
   {  return "Enter description";   }
   
   return "true";
}