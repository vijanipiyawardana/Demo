package com.vijani.newShopREST.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import com.vijani.newShopREST.entity.Item;
import com.vijani.newShopREST.repository.ItemRepository;

@Service
public class ItemDAO {

	@Autowired
	ItemRepository itemRepository;

	/* SAVE AN ITEM */
	@Transactional(readOnly = false, isolation = Isolation.READ_COMMITTED)
	public Item save(Item item) {
		return itemRepository.save(item);
	}

	/* GET ALL ITEMS */
	public List<Item> findAll() {
		return itemRepository.findAll();
	}

	/* GET AN ITEM */
	public Item findOne(Long id) {
		Optional<Item> op = itemRepository.findById(id);
		if (op.isPresent()) {
			return op.get();
		} else {
			return null;
		}
	}

	/* DELETE AN ITEM */
	@Transactional(readOnly = false, isolation = Isolation.READ_COMMITTED)
	public void delete(Item item) {
		itemRepository.delete(item);
	}
}
