package com.vijani.newShopREST.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vijani.newShopREST.dao.ItemDAO;
import com.vijani.newShopREST.entity.Item;

@RestController
@RequestMapping("/shop")
public class ItemController {

	@Autowired
	ItemDAO itemDAO;

	/* SAVE AN ITEM */
	@PostMapping("/items")
	public Item createEmployee(@Valid @RequestBody Item item) {
		return itemDAO.save(item);
	}

	/* GET ALL ITEMS */
	@GetMapping("/items")
	public List<Item> getAllItems() {
		return itemDAO.findAll();
	}

	/* GET AN ITEM BY ID */
	@GetMapping("/items/{id}")
	public ResponseEntity<Item> getItemById(@PathVariable(value = "id") Long id) {
		Item item = itemDAO.findOne(id);

		if (item == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok().body(item);
	}

	/* UPDATE AN ITEM */
	@PutMapping("/items/{id}")
	public ResponseEntity<Item> updateEmployee(@PathVariable(value = "id") Long id,
			@Valid @RequestBody Item itemDetails) {

		Item item = itemDAO.findOne(id);

		if (item == null) {
			return ResponseEntity.notFound().build();
		}
		item.setName(itemDetails.getName());
		item.setQtyOnHand(itemDetails.getQtyOnHand());
		item.setUnitPrice(itemDetails.getUnitPrice());

		Item updatedItem = itemDAO.save(item);

		return ResponseEntity.ok().body(updatedItem);
	}

	/* DELETE AN ITEM */
	@DeleteMapping("/items/{id}")
	public ResponseEntity<Item> deleteEmployee(@PathVariable(value = "id") Long id) {
		Item item = itemDAO.findOne(id);
		if (item == null) {
			return ResponseEntity.notFound().build();
		}
		itemDAO.delete(item);
		return ResponseEntity.ok().build();
	}
}
