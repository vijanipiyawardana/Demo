package com.vijani.newShopREST.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vijani.newShopREST.entity.Item;

public interface ItemRepository extends JpaRepository<Item, Long> {

}
