package com.vijani.newShopREST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewShopRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewShopRestApplication.class, args);
	}

}
