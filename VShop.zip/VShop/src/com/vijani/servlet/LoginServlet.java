package com.vijani.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vijani.controller.CustomerController;
import com.vijani.model.Customer;

public class LoginServlet extends HttpServlet {

	private static final long serialVersionUID = 1024933026485904788L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		Customer customer = new Customer();
		
		customer.setUsername(request.getParameter("username"));
		customer.setPassword(request.getParameter("password"));
		
		Boolean b = false;
		CustomerController cc = new CustomerController();
		try {
			b = cc.login(customer);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		if(b) {
			//System.out.println("this is true..");
			request.getRequestDispatcher("item.jsp").forward(request, response);
		}
		else {
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
	}
}
