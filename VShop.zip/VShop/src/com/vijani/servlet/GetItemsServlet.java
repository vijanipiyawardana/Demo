package com.vijani.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vijani.controller.ItemController;
import com.vijani.model.Item;


public class GetItemsServlet extends HttpServlet {

	private static final long serialVersionUID = 8539109743178761761L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		ArrayList<Item> items = null;
		ItemController ic = new ItemController();
		
		try {
			items = ic.getAllItems();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ObjectMapper mapper = new ObjectMapper(); 
        String itemsString = mapper.writeValueAsString(items);
		response.getWriter().append(itemsString);	
	}
}
