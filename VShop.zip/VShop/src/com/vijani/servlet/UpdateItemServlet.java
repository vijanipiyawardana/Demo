package com.vijani.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vijani.controller.ItemController;
import com.vijani.model.Item;

public class UpdateItemServlet extends HttpServlet{

	private static final long serialVersionUID = -7261532019992816850L;
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		Integer id = (Integer.parseInt(request.getParameter("id")));
		String updatedName = request.getParameter("newName");
		Integer updatedQty = (Integer.parseInt(request.getParameter("newQty")));
		Float updatedUnitPrice = (Float.parseFloat(request.getParameter("newUnitPrice")));
	
		Item item = null;
		ItemController ic = new ItemController();
		
		try {
			item = ic.getItemByID(id);
			System.out.println("itemmmm " + item.getId() + " " + item.getItemName()+ " " + item.getQtyOnHand()+ " "+ item.getUnitPrice());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		item.setItemName(updatedName);
		item.setQtyOnHand(updatedQty);
		item.setUnitPrice(updatedUnitPrice);
		
		try {
			ic.updateItem(id, item);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		response.getWriter().write("item updated");
	}

}
