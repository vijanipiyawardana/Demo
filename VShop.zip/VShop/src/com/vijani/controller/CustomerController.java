package com.vijani.controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.vijani.database.DBConnector;
import com.vijani.database.DBHandler;
import com.vijani.model.Customer;

public class CustomerController {
	
	public boolean login(Customer customer) throws ClassNotFoundException, SQLException{
		String s = isValidFormLogin(customer);
		if(s=="success") {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean logout() {
		return true;
	}
	
	private String isValidFormLogin(Customer customer) throws ClassNotFoundException, SQLException{
		String status = "invalid user credentials...!";
		String query = "SELECT * FROM customer;";
		ResultSet rst = DBHandler.getData(DBConnector.getConnectionToDB(), query);
		
		String usernameDB = "";
		String passwordDB = "";
		while(rst.next()) {
			usernameDB = rst.getString(1);
			passwordDB = rst.getString(2);
			
			if((usernameDB.equals(customer.getUsername())) && passwordDB.equals(customer.getPassword())) {
				status = "success";
				break;
			}	
		}
		return status;
	}
	
	public boolean isLoggedCustomer() {
		return true;
	}
}
