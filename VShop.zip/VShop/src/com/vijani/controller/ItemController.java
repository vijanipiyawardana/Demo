package com.vijani.controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.vijani.database.DBConnector;
import com.vijani.database.DBHandler;
import com.vijani.model.Item;

public class ItemController {
	
	public int saveItem(Item item) throws ClassNotFoundException, SQLException{
		
		String query = "INSERT INTO item (itemName,qtyOnHand,unitPrice) "
				+ "VALUES('" + item.getItemName() + "','"
				+ item.getQtyOnHand() + "','"
				+ item.getUnitPrice() + "');";
		System.out.println(query);
		int res = DBHandler.setData(DBConnector.getConnectionToDB(), query); 
		return res;
	}
	
	public ArrayList<Item> getAllItems() throws ClassNotFoundException, SQLException{
		
		String query = "SELECT * FROM item;";
		ResultSet rst = DBHandler.getData(DBConnector.getConnectionToDB(), query);
		ArrayList<Item> items = new ArrayList<Item>();
		while(rst.next()) {
			Item item = new Item();
			
			item.setId(rst.getInt(1));
			item.setItemName(rst.getString(2));
			item.setQtyOnHand(rst.getInt(3));
			item.setUnitPrice(rst.getFloat(4));
			
			items.add(item);
		}
		return items;
	}
	
	public Item getItemByID(int id) throws ClassNotFoundException, SQLException{
		String query = "SELECT * FROM item WHERE id='" + id + "';";
		ResultSet rst = DBHandler.getData(DBConnector.getConnectionToDB(), query);
		
		Item item = new Item();
		item.setId(rst.getInt(1));
		item.setItemName(rst.getString(2));
		item.setQtyOnHand(rst.getInt(3));
		item.setUnitPrice(rst.getFloat(4));
		
		return item;
		
	}
	public int deleteItem(int id) throws ClassNotFoundException, SQLException{
		String query = "DELETE FROM item WHERE id ='" + id + "';";
		int res = DBHandler.setData(DBConnector.getConnectionToDB(), query); 
		return res;
		
	}

	public int updateItem(Integer id, Item item) throws ClassNotFoundException, SQLException{
		
		String query = "UPDATE item set itemName='"+ item.getItemName()+"', "
				+ "qtyOnHand='"+ item.getQtyOnHand()+"', "
				+ "unitPrice='"+ item.getUnitPrice()+" WHERE id='"+id+"';";
		System.out.println(query);
		int res = DBHandler.setData(DBConnector.getConnectionToDB(), query); 
		return res;
	}
	
}
