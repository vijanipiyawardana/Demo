package com.vijani.newShopREST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing
public class NewShopRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewShopRestApplication.class, args);
	}

}
